TRAIL TATER CAMPFIRE TEST UPDATE
================================

Purpose
-------
Adds a new RSS item AFTER the Brevo integration was activated, so Brevo has a
fresh item to detect.

Upload
------
Replace the existing root-level campfire.xml on GitHub with this new one.

Expected new item
-----------------
Trail Tater Campfire is live

Important
---------
Do not rename the file. It must remain campfire.xml and stay in the
TrailTater.com repository root.
